<template>
    <div class="fillcontain">
        sendMessage
    </div>
</template>

<script>
    export default {
    	
    }
</script>

<style lang="less">
	@import '../style/mixin';
</style>
