<template>
  <div style="padding:30px;">
    <el-alert title="menu 2" :closable="false" />
  </div>
</template>
